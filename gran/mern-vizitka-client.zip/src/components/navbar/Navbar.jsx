import { Box, Button, Stack, Typography } from '@mui/material'

const NavBar = () => {
  const items = ['ПОВЕРКА', 'ВЕСОВ', 'ВСЕХ', 'ТИПОВ']

  return (
    <Box sx={{ bgcolor: '#1c7c3f', py: 1, maxWidth:1353 }}>
      <Stack direction="row" justifyContent="center"   sx={{marginLeft:{ xs: 0, md: "-489px"}}} spacing={2} flexWrap="wrap">
        {items.map((item, index) => (
          <Typography
            key={index}
            sx={{
              color: 'white',
              fontWeight: 'bold',
              '&:hover': { backgroundColor: '#155f2f' }
            }}
          >
            {item}
          </Typography>
        ))}
      </Stack>
    </Box>
  )
}

export default NavBar
