import {
  Box,
  Container,
  Typography,
  TextField,
  MenuItem,
  Grid,
  Button,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  Dialog,
  DialogContent,
  IconButton,
  Divider,
  CircularProgress, Autocomplete
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { useState, useEffect, useRef } from 'react'
import ExcelJS from 'exceljs'
import { saveAs } from 'file-saver'
import DeleteIcon from '@mui/icons-material/Delete'
import { useAuth } from '../../components/auth-context'
const users = ['Иванов И.И.', 'Петров П.П.', 'Сидоров С.С.', 'Смирнов А.А.']

const imgbbKey = 'dfc6fdfece532c32d930e5d0a1561fbd'

const DataEntryPage = () => {
  const [formData, setFormData] = useState({
    date: '',
    customer: '',
    verifier: '',
    model: '',
    serial: '',
    year: '',
    maxD: '',
    registry: '',
    mp: '',
    location: '',
    certificate: '',
    photo1: null,
    photo2: null,
    photo1Url: '',
    photo2Url: '',
  })
  const [isUploadingImage, setIsUploadingImage] = useState(false)
const [photoDialog, setPhotoDialog] = useState({
url: null,
entryId: null,
field: null, // photo1Url или photo2Url
})
  const [entries, setEntries] = useState([])
  const [uploading, setUploading] = useState({ photo1: false, photo2: false })
  const [previewImage, setPreviewImage] = useState(null)
const [exporting, setExporting] = useState(false)
  const fileInputs = {
    photo1: useRef(null),
    photo2: useRef(null),
  }
  
const [editingCell, setEditingCell] = useState({ id: null, field: null })
const [editedValue, setEditedValue] = useState('')
useEffect(() => {
fetchEntries()
fetchVerifiers()
}, [])
const { user } = useAuth()
const [verifiers, setVerifiers] = useState([])
const fetchVerifiers = async () => {
const res = await fetch('https://mern-vizitka.onrender.com/api/created-users')
const users = await res.json()
const usernames = users.map(u => u.username).slice(0, 4)
setVerifiers(usernames)
}

  const fetchEntries = async () => {
    const res = await fetch('https://mern-vizitka.onrender.com/api/entries')
    const data = await res.json()
    setEntries(data)
  }
const handleEditSave = async (id, field, value) => {
try {
const res = await fetch(`https://mern-vizitka.onrender.com/api/entries/${id}`, {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ [field]: value }),
})
if (!res.ok) throw new Error('Ошибка при сохранении')
const updated = await res.json()
setEntries((prev) =>
prev.map((e) => (e._id === id ? { ...e, [field]: value } : e))
)
} catch (err) {
alert('Ошибка при обновлении: ' + err.message)
} finally {
setEditingCell({ id: null, field: null })
setEditedValue('')
}
}
  const handleChange = (e) => {
    const { name, value, files } = e.target
    if (files && files.length > 0) {
      const file = files[0]
      handlePhotoUpload(name, file)
      // сброс input после выбора
      if (fileInputs[name]?.current) fileInputs[name].current.value = null
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

const role = user?.role
const username = user?.username

const canEdit = (entry) => {
if (role === 'admin' || role === 'full') return true
if (role === 'limited') return entry.createdBy === username
return false
}
const canDelete = (entry) => {
if (role === 'admin' || role === 'full') return true
if (role === 'limited') return entry.createdBy === username
return false
}
const canAdd = role !== 'viewer'
const uploadToImgBB = async (file) => {
  const formData = new FormData()
  formData.append('image', file)
  const res = await fetch(`https://api.imgbb.com/1/upload?key=${imgbbKey}`, {
    method: 'POST',
    body: formData,
  })
  const data = await res.json()
  return data?.data?.url || ''
}

  const handlePhotoUpload = async (name, file) => {
    setUploading((prev) => ({ ...prev, [name]: true }))
    const url = await uploadToImgBB(file)
    const urlField = name === 'photo1' ? 'photo1Url' : 'photo2Url'
    setFormData((prev) => ({
      ...prev,
      [name]: file,
      [urlField]: url,
    }))
    setUploading((prev) => ({ ...prev, [name]: false }))
  }

 const isFormValid = () => {
const required = [
'date', // Дата
'customer', // Заказчик/Владелец
'verifier', // Поверитель
'model', // Модель весов
'serial', // Зав. №
'year', // Год выпуска
'maxD', // Темп/влажность
'location' // Место поверки
]
return required.every((key) => formData[key])
}

  const handleExport = () => {
const headers = [
'№', 'Дата','Заказчик/Владелец', 'Поверитель', 'Модель', 'Зав. №',
'Год', 'Темп/Влажность', 'Реестр', 'МП', 'Место',
'Свидетельство', 'Фото1', 'Фото2', 'Кто внес',
]

const data = entries.map((entry, index) => [
entries.length - index,
entry.date,
entry.customer,
entry.verifier,
entry.model,
entry.serial,
entry.year,
entry.maxD,
entry.registry,
entry.mp,
entry.location,
entry.certificate,
entry.photo1Url,
entry.photo2Url,
entry.createdBy,
])

const worksheet = XLSX.utils.aoa_to_sheet([headers, ...data])
const workbook = XLSX.utils.book_new()
XLSX.utils.book_append_sheet(workbook, worksheet, 'Поверки')

XLSX.writeFile(workbook, 'table_export.xlsx')
}

 const handleSubmit = async () => {
try {
const payload = {
...formData,
createdBy: username
}


const res = await fetch('https://mern-vizitka.onrender.com/api/entries', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
})

if (!res.ok) throw new Error('Ошибка при сохранении')
const newEntry = await res.json()

// Обновление записей и проверка лимита
const updatedEntries = [newEntry, ...entries]
setEntries(updatedEntries)

// Если больше 1500 — вызываем очистку старых
if (updatedEntries.length > 1500) {
  const cleanRes = await fetch('https://mern-vizitka.onrender.com/api/entries/old', {
    method: 'DELETE',
  })
  if (!cleanRes.ok) throw new Error('Ошибка при удалении старых записей')

  // После удаления — обновляем данные
  await fetchEntries()
}

// Сброс формы
setFormData({
  date: '',
  customer: '',
  verifier: '',
  model: '',
  serial: '',
  year: '',
  maxD: '',
  registry: '',
  mp: '',
  location: '',
  certificate: '',
  photo1: null,
  photo2: null,
  photo1Url: '',
  photo2Url: '',
})
} catch (err) {
alert('Ошибка при сохранении: ' + err.message)
}
}

const handleExportWithImages = async () => {
    setExporting(true)
const workbook = new ExcelJS.Workbook()
const sheet = workbook.addWorksheet('Поверки')

const headers = [
'№', 'Дата','Заказчик/Владелец', 'Поверитель', 'Модель', 'Зав. №',
'Год', 'Темп/Влажность', 'Реестр', 'МП', 'Место',
'Свидетельство', 'Фото1', 'Фото2', 'Кто внес',
]

const colWidths = [
5, 12,12, 20, 18, 10, 8, 10, 10, 10, 20, 20,
15, 15, 15 // Фото1, Фото2, Кто внес
]

// Установка ширин колонок и общих стилей
sheet.columns = headers.map((header, i) => ({
header,
width: colWidths[i] || 15,
style: {
alignment: { vertical: 'middle', horizontal: 'center', wrapText: true },
font: { size: 10 }
}
}))

// Заголовки
const headerRow = sheet.getRow(1)
headerRow.font = { bold: true, size: 11 }
headerRow.height = 24
headerRow.alignment = { vertical: 'middle', horizontal: 'center' }
headerRow.eachCell((cell) => {
cell.border = {
top: { style: 'thin' },
left: { style: 'thin' },
right: { style: 'thin' },
bottom: { style: 'thin' },
}
cell.fill = {
type: 'pattern',
pattern: 'solid',
fgColor: { argb: 'FFEFEFEF' },
}
})

const IMAGE_WIDTH = 60
const IMAGE_HEIGHT = 45
const PIXELS_PER_CHAR = 7.1 // Excel ~1 column width = 7.1px

for (let i = 0; i < entries.length; i++) {
const entry = entries[i]
const row = sheet.addRow([
  entries.length - i,
  entry.date,
  entry.customer,
  entry.verifier,
  entry.model,
  entry.serial,
  entry.year,
  entry.maxD,
  entry.registry,
  entry.mp,
  entry.location,
  entry.certificate,
  '', '', // placeholders
  entry.createdBy
])
row.height = 50
const imageUrls = [entry.photo1Url, entry.photo2Url]

const photoCols = [13, 14] // Фото1 и Фото2 — это 12-я и 13-я колонки (нумерация с 1)
imageUrls.forEach((url, j) => {
  if (url) {
    const cell = row.getCell(photoCols[j])
    cell.value = { text: '.', hyperlink: url }
    cell.font = { color: { argb: 'FF0000FF' }, underline: true }
  }
})

row.eachCell((cell) => {
  cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }
  cell.font = { size: 10 }
  cell.border = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    right: { style: 'thin' },
    bottom: { style: 'thin' },
  }
})


for (let j = 0; j < imageUrls.length; j++) {
  const url = imageUrls[j]
  if (!url) continue

  try {
    const response = await fetch(url)
    const blob = await response.blob()
    const buffer = await blob.arrayBuffer()
    const ext = blob.type === 'image/png' ? 'png' : 'jpeg'

    const imageId = workbook.addImage({
      buffer,
      extension: ext,
    })

    const colIndex = 12 + j // Фото1, Фото2
  


   const imgWidth = 60
const imgHeight = 45

// Размеры ячейки (примерно)
const colWidthPx = 100   // ширина колонки (в пикселях)
const rowHeightPx = 67   // высота строки (row.height = 50 → ≈67px)

// Смещения в EMU
const offsetX = ((colWidthPx - imgWidth) / 2) * 9525
const offsetY = ((rowHeightPx - imgHeight) / 2) * 9525

sheet.addImage(imageId, {
  tl: { col: 12 + j, row: i + 1, nativeColOff: offsetX, nativeRowOff: offsetY },
  ext: { width: imgWidth, height: imgHeight },
})
  } catch (err) {
    console.warn(`Не удалось загрузить изображение ${url}`, err)
  }
  finally {
    setExporting(false)
  }
}
}

const buffer = await workbook.xlsx.writeBuffer()
saveAs(new Blob([buffer]), 'поверки.xlsx')
}
const getUniqueOptions = (field) => {
  const values = entries.map((e) => e[field]).filter(Boolean)
  return [...new Set(values)]
}
  return (
    <Container maxWidth="xl" sx={{ py: 4, px: { xs: 1, sm: 2, md: 4 } }}>
        <Box mt={2} mb={2}> <Box mt={2} mb={2}>
  <Button
    variant="outlined"
    color="primary"
    sx={{ ml: 2, minWidth: 160 }}
    onClick={handleExportWithImages}
    disabled={exporting}
  >
    {exporting ? (
      <>
        <CircularProgress size={20} sx={{ mr: 1 }} />
        Экспорт...
      </>
    ) : (
      'Экспорт в Excel'
    )}
  </Button>
</Box></Box>
      <Typography variant="h5" fontWeight="bold" gutterBottom>
        Ввод данных поверки
      </Typography>

      {/* === Форма === */}
      {canAdd && (<Box component="form" sx={{ mb: 4 }}>
        <Grid container spacing={2}>
          {[
  { name: 'date', label: 'Дата', type: 'date', md: 2 },
  {
  name: 'customer',
  label: 'Заказчик/Владелец',
  md: 3,

  
},
  { name: 'verifier', label: 'Поверитель', md: 3, options: verifiers },
  {
    name: 'model',
    label: 'Модель весов',
    md: 3,
 
    
  },
  {
    name: 'serial',
    label: 'Зав. №',
    md: 2,
  
  
  },
  { name: 'year', label: 'Год выпуска', md: 2 },
  { name: 'maxD', label: 'Темп/Влажность', md: 3 },
  {
    name: 'registry',
    label: 'Реестр',
    md: 3,

 
  },
  {
    name: 'mp',
    label: 'МП',
    md: 3,

  
  },
  {
    name: 'location',
    label: 'Место поверки',
    md: 3,
  
  
  },
  { name: 'certificate', label: 'Свидетельство', md: 4 },
].map((field) => (
  <Grid key={field.name} item xs={12} minWidth={200} md={field.md}>
    {field.name === 'date' ? (
      <TextField
name="date"
label="Дата *"
type="date"
value={formData.date}
onChange={handleChange}
fullWidth
InputLabelProps={{ shrink: true }}
error={!formData.date}
helperText={!formData.date ? 'Обязательное поле' : ''}
sx={{
'& .MuiOutlinedInput-root': !formData.date
? {
'& fieldset': { borderColor: 'red !important' },
'&:hover fieldset': { borderColor: 'red' },
'&.Mui-focused fieldset': { borderColor: 'red' },
}
: {},
}}
/>
    ) : (
     <Autocomplete
  freeSolo={!field.options}
  options={field.options || getUniqueOptions(field.name)}
  value={formData[field.name] || ''}
  onInputChange={(_, newInput) => {
    const isValid = !field.pattern || field.pattern.test(newInput)
    setFormData((prev) => ({ ...prev, [field.name]: newInput }))
    if (!isValid) console.warn(`Валидация не прошла для ${field.name}: ${newInput}`)
  }}
  renderInput={(params) => {
const required = ['date', 'customer', 'verifier', 'model', 'serial', 'year', 'maxD', 'location']
const isRequired = required.includes(field.name)
const value = formData[field.name] || ''
const isEmpty = isRequired && value.trim() === ''
const showError = isEmpty

return (
<TextField
{...params}
label={isRequired ? `${field.label} *`: field.label}
fullWidth
error={showError}
helperText={showError ? 'Обязательное поле' : ''}
sx={{
'& .MuiOutlinedInput-root': showError
? {
'& fieldset': { borderColor: 'red !important' },
'&:hover fieldset': { borderColor: 'red' },
'&.Mui-focused fieldset': { borderColor: 'red' },
}
: {},
}}
/>
)
}
}

      />
    )}
  </Grid>
))}

          {['photo1', 'photo2'].map((name, i) => (
            <Grid key={name} item xs={12} md={4}>
              <Button
                variant="outlined"
                component="label"
                fullWidth
                disabled={uploading[name]}
              >
                {uploading[name]
                  ? `Фото ${i + 1} — Загрузка...`
                  : formData[`${name}Url`]
                    ? `Фото ${i + 1} — Загружено ✅`
                    : `Фото ${i + 1} (${i === 0 ? 'шильдик' : 'общий вид'})`}
                <input
                  ref={fileInputs[name]}
                  name={name}
                  type="file"
                  hidden
                  onChange={handleChange}
                />
              </Button>
            </Grid>
          ))}
        </Grid>

        <Box mt={3}>
          <Button
            variant="contained"
            color="success"
            onClick={handleSubmit}
            disabled={!isFormValid()}
          >
            Сохранить запись
          </Button>
        </Box>
      </Box>)}

      {/* === Таблица === */}
      <Box sx={{ overflowX: 'auto', maxHeight: '80vh' }}>
        <Paper elevation={2} sx={{ minWidth: 1000 }}>
          <Table
            size="small"
            stickyHeader
            sx={{
              tableLayout: 'fixed',
              '& th, & td': {
                padding: '6px',
                fontSize: '0.85rem',
                wordBreak: 'break-word',
                whiteSpace: 'pre-line',
                textAlign: 'center',
                verticalAlign: 'middle',
              },
            }}
          >
            <TableHead sx={{ bgcolor: '#f9f9f9', position: 'sticky', top: 0, zIndex: 1 }}>
              <TableRow>
                {[
                  '№', 'Дата','Заказчик/Владелец', 'Поверитель', 'Модель', 'Зав. №',
                  'Год', 'Темп/Влажность', 'Реестр', 'МП', 'Место',
                  'Свидетельство', 'Фото1', 'Фото2', 'Кто внес'
                ].map((head, idx) => (<>
                  <TableCell key={idx} sx={{ fontWeight: 'bold', borderRight: '1px solid #ddd' }}>
                    {head}
                  </TableCell>
       
                  </>
                  
                ))}

                           <TableCell sx={{ fontWeight: 'bold', borderRight: '1px solid #ddd' }}>
🗑
</TableCell>
              </TableRow>
            </TableHead>
        <TableBody>
{entries.map((entry, index) => (
<TableRow key={entry._id}>
<TableCell>{entries.length - index}</TableCell>


  {[
    'date',
    'customer',
    'verifier',
    
    'model',
    'serial',
    'year',
    'maxD',
    'registry',
    'mp',
    'location',
    'certificate',
  ].map((field) => (<>
    <TableCell
      key={field}
     onClick={() => {
if (!canEdit(entry)) return
setEditingCell({ id: entry._id, field })
setEditedValue(entry[field])
}}
      sx={{
        cursor: 'pointer',
        backgroundColor:
          editingCell.id === entry._id && editingCell.field === field ? '#e6f2ff' : 'inherit',
      }}
    >
      {editingCell.id === entry._id && editingCell.field === field ? (
        <TextField
          value={editedValue}
          variant="standard"
          autoFocus
          fullWidth
          onChange={(e) => setEditedValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleEditSave(entry._id, field, editedValue)
            } else if (e.key === 'Escape') {
              setEditingCell({ id: null, field: null })
              setEditedValue('')
            }
          }}
          onBlur={() => {
            setEditingCell({ id: null, field: null })
            setEditedValue('')
          }}
        />
      ) : (
        entry[field]
      )}
    </TableCell>
   
    </>
  ))}
 
{[entry.photo1Url, entry.photo2Url].map((url, i) => {
const field = i === 0 ? 'photo1Url' : 'photo2Url'
return (
<TableCell key={field}>
{url && (
<img
src={url}
alt={`Фото ${i + 1}`}
style={{ width: 60, cursor: 'pointer', borderRadius: 4 }}
onClick={() => {
setPhotoDialog({ url, entryId: entry._id, field })
}}
/>
)}
</TableCell>
)
})}
  <TableCell>{entry.createdBy}</TableCell>
  {canDelete(entry) && (<TableCell> <IconButton onClick={async () => { const confirmed = window.confirm('Вы уверены, что хотите удалить эту запись?')
     if (!confirmed) return

  try {
    const res = await fetch(`https://mern-vizitka.onrender.com/api/entries/${entry._id}`, {
      method: 'DELETE',
    })

    if (!res.ok) throw new Error('Ошибка удаления')
    setEntries((prev) => prev.filter((e) => e._id !== entry._id))
  } catch (err) {
    alert('Ошибка при удалении: ' + err.message)
  } 
}}
size="small"
color="error">

<DeleteIcon fontSize="small" />
</IconButton> </TableCell>)}
</TableRow>
))}
</TableBody>
          </Table>
        </Paper>
      </Box>

      {/* Просмотр фото */}
      <Dialog open={!!photoDialog.url} onClose={() => setPhotoDialog({ url: null, entryId: null, field: null })} maxWidth="md" > <DialogContent sx={{ position: 'relative' }}> <IconButton onClick={() => setPhotoDialog({ url: null, entryId: null, field: null })} sx={{ position: 'absolute', top: 8, right: 8, zIndex: 1 }} > <CloseIcon /> </IconButton>

<Box sx={{ minHeight: 200, display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: 2 }}>
  {isUploadingImage ? (
    <CircularProgress />
  ) : (
    photoDialog.url && (
      <img
        src={photoDialog.url}
        alt="Фото"
        style={{ width: '100%', height: 'auto' }}
      />
    )
  )}
</Box>

<Button
  variant="contained"
  component="label"
  fullWidth
  color="primary"
>
  Заменить фото
  <input
    type="file"
    accept="image/*"
    hidden
   onChange={async (e) => {
const file = e.target.files[0]
if (!file || !photoDialog.field || !photoDialog.entryId) return

const entry = entries.find((e) => e._id === photoDialog.entryId)
if (!canEdit(entry)) {
  alert('Недостаточно прав для замены фото.')
  return
}

setIsUploadingImage(true)

try {
  const formData = new FormData()
  formData.append('image', file)
  const res = await fetch(`https://api.imgbb.com/1/upload?key=${imgbbKey}`, {
    method: 'POST',
    body: formData,
  })
  const data = await res.json()
  const newUrl = data?.data?.url

  if (newUrl) {
    await fetch(`https://mern-vizitka.onrender.com/api/entries/${photoDialog.entryId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [photoDialog.field]: newUrl }),
    })

    setEntries((prev) =>
      prev.map((entry) =>
        entry._id === photoDialog.entryId
          ? { ...entry, [photoDialog.field]: newUrl }
          : entry
      )
    )

    setPhotoDialog((prev) => ({
      ...prev,
      url: newUrl,
    }))
  }
} catch (err) {
  alert('Ошибка при загрузке изображения')
} finally {
  e.target.value = null
  setIsUploadingImage(false)
}
}}
  />
</Button>
</DialogContent> </Dialog>
    </Container>
  )
}

export default DataEntryPage
