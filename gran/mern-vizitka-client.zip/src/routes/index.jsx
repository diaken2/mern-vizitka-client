import LoginPage from '../pages/login';
import TablePage from '../pages/data-entry';
import AdminPage from '../pages/admin-panel';
import HomePage from '../components/hero/Hero.jsx';

export const publicRoutes = [
  { path: '/', element: <HomePage /> },
  { path: '/login', element: <LoginPage /> },
];

export const roleBasedRoutes = {
  admin: [
    { path: '/admin', element: <AdminPage /> },
    { path: '/table', element: <TablePage /> },
  ],
  full: [
    { path: '/table', element: <TablePage /> },
  ],
  limited: [
    { path: '/table', element: <TablePage /> },
  ],
  viewer: [
    { path: '/table', element: <TablePage /> },
  ],
};