
import RouterComponent from './components/router-component';
import { AuthProvider } from './components/auth-context';
import Header from "./components/header/Header";
import { useLocation } from 'react-router-dom';

import NavBar from './components/navbar/Navbar';

function App() {
  const location = useLocation();
  const isLoginPage = location.pathname === '/login';
  return (
    <AuthProvider>
      {!isLoginPage && <Header />}
     <NavBar/>
      <RouterComponent />
    </AuthProvider>
  );
}

export default App;